from flask import Flask, render_template, redirect, url_for
from project import create_app, db
from project.user_management import user_management_bp
from project.account_binding import account_binding_bp
from project.models import User

app = create_app()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    from project.user_management import login
    return login()

@app.route('/sign_up', methods=['GET', 'POST'])
def sign_up():
    from project.user_management import register
    return register()

@app.route('/sign_pad')
def sign_pad():
    return render_template('sign_pad.html')

@app.route('/how_it_works')
def how_it_works():
    return render_template('how_it_works.html')

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    from project.account_binding import forgot_password
    return forgot_password()

@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    from project.account_binding import reset_password_token
    return reset_password_token(token)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
