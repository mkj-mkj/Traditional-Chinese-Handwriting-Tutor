from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash, current_app
from .models import db, User, UserCredential, PasswordResetToken
from flask_mail import Message
from . import mail
import os
import binascii
import hashlib
import datetime

account_binding_bp = Blueprint('account_binding', __name__)

def generate_reset_token():
    return binascii.hexlify(os.urandom(24)).decode()

def send_email(to, subject, template, **kwargs):
    try:
        msg = Message(subject, sender=current_app.config['MAIL_USERNAME'], recipients=[to])
        msg.body = f'Click the link to reset your password: {kwargs["reset_url"]}'
        mail.send(msg)
        print(f"Email sent to {to}")
    except Exception as e:
        print(f"Failed to send email to {to}: {str(e)}")
        
# @account_binding_bp.route('/test_mail')
# def test_mail():
#     send_email('recipient_email@gmail.com', 'Test Email', 'email/test', reset_url='http://example.com')
#     return 'Email sent!'

def hash_password(password, salt):
    pbkdf2_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000, dklen=32)
    return binascii.hexlify(pbkdf2_hash).decode('utf-8')

@account_binding_bp.route('/bind_external_account', methods=['POST'])
def bind_external_account():
    data = request.form
    user_id = data.get('user_id')
    external_account = data.get('external_account')

    user = User.query.get(user_id)
    if user:
        user.external_account = external_account
        db.session.commit()
        return jsonify({'message': 'External account bound successfully'}), 200
    else:
        return jsonify({'error': 'User not found'}), 404

@account_binding_bp.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(account=email).first()
        if user:
            token = generate_reset_token()
            expires_at = datetime.datetime.now() + datetime.timedelta(hours=1)
            reset_token = PasswordResetToken(user_id=user.user_id, token=token, expires_at=expires_at)
            db.session.add(reset_token)
            db.session.commit()

            reset_url = url_for('reset_password', token=token, _external=True)
            send_email(user.account, 'Reset Your Password', 'email/reset_password', reset_url=reset_url)
            flash('An email has been sent with instructions to reset your password.', 'info')
        else:
            flash('Email not found', 'error')
        return redirect(url_for('forgot_password'))
    return render_template('forgot_password.html')

@account_binding_bp.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password_token(token):
    reset_token = PasswordResetToken.query.filter_by(token=token).first()
    if reset_token and reset_token.expires_at > datetime.datetime.now():
        if request.method == 'POST':
            new_password = request.form['new_password']
            user = User.query.get(reset_token.user_id)
            if user:
                user_salt = binascii.hexlify(os.urandom(16)).decode('utf-8')
                password_hash = hash_password(new_password, user_salt)

                user.user_salt = user_salt
                user_credential = UserCredential.query.filter_by(hash_user_id=user.user_id).first()
                user_credential.hash_user_pwd = password_hash

                db.session.commit()
                flash('Your password has been updated!', 'success')
                return redirect(url_for('login'))
        return render_template('reset_password.html', token=token)
    else:
        flash('The reset link is invalid or has expired', 'error')
        return redirect(url_for('forgot_password'))

