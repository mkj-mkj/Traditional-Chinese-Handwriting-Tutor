from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required
from .models import db, User, UserCredential
import os
import hashlib

user_management_bp = Blueprint('user_management', __name__)

def hash_password(password, salt):
    combined_string = (password + salt).strip()
    return hashlib.sha256(combined_string.encode()).hexdigest()

def get_user_with_credentials(account):
    return db.session.query(User, UserCredential).\
        join(UserCredential, User.user_id == UserCredential.hash_user_id).\
        filter(User.account == account).\
        first()

@user_management_bp.route('/sign_up', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        if User.query.filter_by(account=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('user_management.register'))
        
        user_salt = os.urandom(16).hex()
        password_hash = hash_password(password, user_salt)
        new_user = User(name=name, account=email, user_salt=user_salt, is_filed=False)
        db.session.add(new_user)
        db.session.commit()

        user_id = new_user.user_id
        new_user_credential = UserCredential(hash_user_id=user_id, hash_user_pwd=password_hash)
        db.session.add(new_user_credential)
        db.session.commit()

        flash('User registered successfully', 'success')
        return redirect(url_for('user_management.login'))
    return render_template('sign_up.html')

@user_management_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        account = request.form['account']
        password = request.form['password']
        user = get_user_with_credentials(account)
        if user and user[1].hash_user_pwd == hash_password(password, user[0].user_salt):
            login_user(user[0])
            flash('Login successful', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid credentials', 'error')
            return redirect(url_for('user_management.login'))
    return render_template('login.html')

@user_management_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully', 'success')
    return redirect(url_for('user_management.login'))

