import numpy as np
#from tensorflow.keras.models import load_model
from PIL import Image
import cv2
import io
import os
from flask import Blueprint, request, jsonify, make_response, session
import json
#from flask_cors import CORS
#import pickle
#import joblib
from .signature_verification_prediction import signature_verification
from .signature_verification_model_update import update_model
from project import db  
from .models import User
import tempfile


signature_verification_bp = Blueprint('signature_verification', __name__,)


#把numpy class轉換成 Json serializable object
class JsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer, np.floating, np.bool_)):
            return obj.item()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(JsonEncoder, self).default(obj)
        
def save_image_to_temp_file(image_data):
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
    temp_file.write(image_data)
    temp_file.close()
    return temp_file.name

                                                               
# API路由
@signature_verification_bp.route('/predict', methods=['POST'])
def predict():
    print("Current working directory:", os.getcwd())
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    try:
        image = request.files['image'].read()
        prediction = signature_verification(image)
        predicted_class = int(prediction)

        user_id = session.get('user_id')  # 從session中取user_id
        is_filed = session.get('is_filed')
        print(f"predicted_class: {predicted_class}, type: {type(predicted_class)}")
        print(f"user_id: {user_id}, type: {type(user_id)}")
        print(f"is_filed: {is_filed}, type: {type(is_filed)}")

        if user_id is None:
            return jsonify({'error': 'User not logged in'}), 401
        
        if is_filed == False:
            temp_image_path = save_image_to_temp_file(image)
            update_model([temp_image_path],[user_id])
            session['is_filed'] = 1
            db.session.commit()  
            verification_result = 'File created'
            print(f"is_filed: {is_filed}, type: {type(is_filed)}")
        else:
            if predicted_class == int(user_id):
                verification_result = '符合'
            else:
                verification_result = '不符合'

        response = make_response(json.dumps({'Verification Result': verification_result}, ensure_ascii=False))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        # 清理臨時圖片
        if temp_image_path and os.path.exists(temp_image_path):
            os.remove(temp_image_path)
