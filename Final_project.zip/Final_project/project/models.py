from . import db, login_manager
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    account = db.Column(db.String(45), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    user_salt = db.Column(db.String(64), nullable=False)
    is_filed = db.Column(db.Boolean, default=False)

class UserCredential(db.Model):
    __tablename__ = 'user_credential'
    hash_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    hash_user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), unique=True, nullable=False)
    hash_user_pwd = db.Column(db.String(255), nullable=False)

class PasswordResetToken(db.Model):
    __tablename__ = 'password_reset_token'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), nullable=False)
    token = db.Column(db.String(64), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
