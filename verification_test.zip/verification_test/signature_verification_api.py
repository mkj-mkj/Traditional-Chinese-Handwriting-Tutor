import numpy as np
from tensorflow.keras.models import load_model
from PIL import Image
import cv2
import io
import os
from flask import Flask, request, jsonify, make_response
import json
from flask_cors import CORS
import joblib
import signature_verification_model_train
import signature_verification_model_update
import signature_verification_prediction
import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import accuracy_score
import joblib



app = Flask(__name__)
CORS(app)
CORS(app, resources={r"/predict": {"origins": "http://localhost:8000"}})  # 允許從http://localhost:8000請求
                                                                          #cd C:\Users\user\Desktop\專題\畢業專題\分類模型
                                                                          #python -m http.server 8000
                                                                

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    try:
        image = request.files['image'].read()
        img = Image.open(io.BytesIO(image)).convert('RGB').resize((200, 200))
        user_id = request.form['user_id']
        
        # 進行預測
        prediction = signature_verification_prediction.signature_verification(img)
        # 將 prediction 轉換為 int 類型
        predicted_class = int(prediction)

        if predicted_class == user_id:
            verification_result = 1
        else:
            verification_result = 0
        
        
        # 使用 json.dumps 並設置 ensure_ascii=False 回傳中文
        response = make_response(json.dumps({'verification result': verification_result}, ensure_ascii=False))
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        app.logger.error('An error occurred: %s', str(e))
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)