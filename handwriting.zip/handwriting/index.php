<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

// 建立連接
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接
if ($conn->connect_error) {
    die("連接失敗: " . $conn->connect_error);
}

// 查詢數據
/*
$sql = "SELECT id, name FROM my_table";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 輸出數據
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. "<br>";
    }
} else {
    echo "0 結果";
}
$conn->close();
?>
*/
